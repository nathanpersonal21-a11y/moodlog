# Moodlog — Setup Guide

A free, private mood + journal PWA for iPhone. No paid services required.

---

## What you get

- Daily mood check-in (1–100 dial) every time you open the app
- Unlimited **text journal entries**
- Unlimited **voice journal entries** with browser-based transcription
- Optional GPS location tagging
- All data stored in **your own Google Sheet**
- Audio files stored in **your own Google Drive**
- Works offline (saves locally, syncs when online)
- Installable on iPhone home screen as a standalone app

---

## Step 1 — Host the app (free)

You need to serve `index.html` over HTTPS. Easiest free options:

### Option A: GitHub Pages (recommended)
1. Create a free account at [github.com](https://github.com)
2. Create a new **public** repository named `moodlog`
3. Upload `index.html` to the repository root
4. Go to **Settings → Pages → Source → Deploy from branch → main / root**
5. Your app will be at `https://YOUR-USERNAME.github.io/moodlog`

### Option B: Netlify
1. Go to [netlify.com](https://netlify.com) → sign up free
2. Drag and drop the folder containing `index.html` onto the Netlify deploy area
3. Your app gets a free `https://…netlify.app` URL

### Option C: Any HTTPS web host
Upload `index.html` to any web host that serves HTTPS.

> **Important:** The app must be served over HTTPS for the microphone and GPS to work.

---

## Step 2 — Set up Google Apps Script

### 2a. Create a Google Sheet
1. Go to [sheets.google.com](https://sheets.google.com)
2. Create a new spreadsheet — name it **Moodlog**
3. Note the spreadsheet URL (you'll need it in a moment)

### 2b. Open the Apps Script editor
1. In your Moodlog spreadsheet, click **Extensions → Apps Script**
2. Delete all the existing code in the editor
3. Copy the entire contents of `apps-script.js` and paste it in
4. Click **Save** (the floppy disk icon)

### 2c. Run the setup function
1. In the Apps Script editor, select the function `setup` from the dropdown
2. Click **Run**
3. Grant the permissions it requests (it needs access to your Sheet and Drive)
4. Check the **Execution log** — you should see "Setup complete"

### 2d. Deploy as a Web App
1. Click **Deploy → New deployment**
2. Click the gear icon next to **Type** and select **Web app**
3. Fill in:
   - **Description:** Moodlog API
   - **Execute as:** Me
   - **Who has access:** Anyone
4. Click **Deploy**
5. Copy the **Web app URL** — it looks like:
   `https://script.google.com/macros/s/LONG_ID_HERE/exec`

> **Keep this URL private** — anyone with it can write to your sheet.

---

## Step 3 — Connect the app to your sheet

1. Open your Moodlog app URL in Safari on your iPhone
2. Tap the **⚙** settings button (top right of the home screen)
3. Paste your **Google Apps Script Web App URL** into the field
4. Tap **Save settings**

The app will now sync every new entry to your Google Sheet automatically.

---

## Step 4 — Add to iPhone Home Screen

1. Open your app URL in **Safari** on iPhone
2. Tap the **Share** button (the box with the arrow)
3. Scroll down and tap **Add to Home Screen**
4. Name it **Moodlog** and tap **Add**

The app now opens full-screen with no browser UI, just like a native app.

---

## Data structure in Google Sheets

Each entry creates one row with these columns:

| Column | Contents |
|--------|----------|
| A | Timestamp (ISO 8601) |
| B | Timestamp (human-readable) |
| C | Mood Score (1–100) |
| D | Mood Label (e.g. "radiant") |
| E | Entry Type (text / voice) |
| F | Written Text |
| G | Voice Transcript |
| H | Latitude |
| I | Longitude |
| J | GPS Accuracy (meters) |
| K | Google Drive Audio URL |

---

## Audio files

Voice recordings are stored as WebM/Opus files in a **Moodlog Audio** folder in your Google Drive. Each file is named `moodlog-TIMESTAMP.webm` and set to "Anyone with link can view." The Drive URL is stored in column K of your sheet.

> **Note:** Audio upload requires a direct (non-no-cors) fetch to the Apps Script URL. If uploads fail, check that your deployment is set to "Anyone" access. Text entries use `mode: no-cors` and always work.

---

## Troubleshooting

**Mood dial doesn't respond**  
Make sure you're using Safari on iOS. Chrome/Firefox on iPhone don't support all PWA features.

**Microphone not working**  
The app must be on HTTPS. Localhost won't work for microphone access.

**Transcription not appearing**  
Web Speech API (webkitSpeechRecognition) is supported in Safari 14.1+ and Chrome. Firefox does not support it. Transcription is best-effort — the recording always saves even if transcription fails.

**Entries not syncing**  
1. Check that your Apps Script URL is correct in Settings
2. Make sure your deployment is set to "Anyone" access (not "Anyone with Google account")
3. If you redeploy, you get a NEW URL — update it in Settings

**Re-deploying after code changes**  
Go to Apps Script → Deploy → Manage deployments → click the pencil icon → change version to "New version" → Deploy. The URL stays the same.

---

## Privacy

- All journal data stays in YOUR Google account
- No third-party servers ever see your data (except Google)
- The app code itself has no analytics, tracking, or external requests
- Location data is only sent if you explicitly tap "Add" location

---

## Cost

**$0.00** — forever.

- GitHub Pages / Netlify: free tier is ample
- Google Apps Script: free (6 min/execution, 20k URL fetch/day limits — far beyond personal use)
- Google Drive: free 15 GB shared across Drive/Gmail/Photos
- Google Sheets: free
