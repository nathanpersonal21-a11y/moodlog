// ================================================================
//  MOODLOG — Google Apps Script Backend
//  Paste this entire file into script.google.com
//  then Deploy > New deployment > Web app
//  Execute as: Me | Who has access: Anyone
// ================================================================

const SHEET_NAME = 'Entries';
const DRIVE_FOLDER_NAME = 'Moodlog Audio';

// ----------------------------------------------------------------
//  Web App Entry Points
// ----------------------------------------------------------------

function doGet(e) {
  return ContentService
    .createTextOutput(JSON.stringify({ status: 'ok', message: 'Moodlog API running' }))
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);
    const action = body.action;

    let result;
    if (action === 'addEntry') {
      result = addEntry(body);
    } else if (action === 'uploadAudio') {
      result = uploadAudio(body);
    } else {
      result = { success: false, error: 'Unknown action: ' + action };
    }

    return ContentService
      .createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ success: false, error: err.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// ----------------------------------------------------------------
//  Add a journal entry to the Google Sheet
// ----------------------------------------------------------------

function addEntry(data) {
  const sheet = getOrCreateSheet();

  const row = [
    data.timestamp || new Date().toISOString(),  // A: Timestamp (ISO)
    new Date().toLocaleString('en-US'),           // B: Human-readable timestamp
    data.moodScore || '',                          // C: Mood score (1-100)
    getMoodLabel(Number(data.moodScore)),          // D: Mood label
    data.type || 'text',                           // E: Entry type (text/voice)
    data.text || '',                               // F: Written text
    data.transcript || '',                         // G: Voice transcript
    data.latitude || '',                           // H: Latitude
    data.longitude || '',                          // I: Longitude
    data.accuracy || '',                           // J: GPS accuracy (meters)
    data.driveUrl || '',                           // K: Google Drive audio URL
  ];

  sheet.appendRow(row);

  return { success: true, row: row };
}

// ----------------------------------------------------------------
//  Upload audio to Google Drive, return file URL
// ----------------------------------------------------------------

function uploadAudio(data) {
  const folder = getOrCreateFolder();
  const filename = data.filename || ('moodlog-audio-' + Date.now() + '.webm');
  const mimeType = data.mimeType || 'audio/webm';

  // Decode base64 to blob
  const decoded = Utilities.base64Decode(data.data);
  const blob = Utilities.newBlob(decoded, mimeType, filename);

  const file = folder.createFile(blob);
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);

  const driveUrl = 'https://drive.google.com/file/d/' + file.getId() + '/view';

  return { success: true, driveUrl: driveUrl, fileId: file.getId() };
}

// ----------------------------------------------------------------
//  Helper: Get or create the Entries sheet
// ----------------------------------------------------------------

function getOrCreateSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);

  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
    // Write header row
    const headers = [
      'Timestamp (ISO)',
      'Timestamp (Readable)',
      'Mood Score',
      'Mood Label',
      'Entry Type',
      'Written Text',
      'Voice Transcript',
      'Latitude',
      'Longitude',
      'GPS Accuracy (m)',
      'Audio Drive URL'
    ];
    sheet.appendRow(headers);

    // Style header row
    const headerRange = sheet.getRange(1, 1, 1, headers.length);
    headerRange.setFontWeight('bold');
    headerRange.setBackground('#1a1a2e');
    headerRange.setFontColor('#c8a96e');

    // Freeze header
    sheet.setFrozenRows(1);

    // Set column widths
    sheet.setColumnWidth(1, 200);
    sheet.setColumnWidth(2, 180);
    sheet.setColumnWidth(3, 100);
    sheet.setColumnWidth(4, 120);
    sheet.setColumnWidth(5, 90);
    sheet.setColumnWidth(6, 300);
    sheet.setColumnWidth(7, 300);
    sheet.setColumnWidth(8, 100);
    sheet.setColumnWidth(9, 100);
    sheet.setColumnWidth(10, 120);
    sheet.setColumnWidth(11, 350);
  }

  return sheet;
}

// ----------------------------------------------------------------
//  Helper: Get or create the Moodlog Audio Drive folder
// ----------------------------------------------------------------

function getOrCreateFolder() {
  const folders = DriveApp.getFoldersByName(DRIVE_FOLDER_NAME);
  if (folders.hasNext()) {
    return folders.next();
  }
  return DriveApp.createFolder(DRIVE_FOLDER_NAME);
}

// ----------------------------------------------------------------
//  Helper: Convert numeric score to label
// ----------------------------------------------------------------

function getMoodLabel(score) {
  if (!score || isNaN(score)) return 'unknown';
  const labels = [
    'desolate',   // 1-10
    'low',        // 11-20
    'subdued',    // 21-30
    'heavy',      // 31-40
    'weary',      // 41-50
    'okay',       // 51-60  (note: app maps 50 = neutral/weary boundary)
    'steady',     // 61-70
    'good',       // 71-80  (note: app maps 80 = good)
    'bright',     // 81-90
    'radiant',    // 91-100
  ];
  const idx = Math.min(9, Math.max(0, Math.ceil(score / 10) - 1));
  return labels[idx];
}

// ----------------------------------------------------------------
//  One-time setup function — run this manually once to
//  create the spreadsheet structure before deploying
// ----------------------------------------------------------------

function setup() {
  getOrCreateSheet();
  getOrCreateFolder();
  Logger.log('Setup complete. Sheet and Drive folder created.');
  Logger.log('Spreadsheet URL: ' + SpreadsheetApp.getActiveSpreadsheet().getUrl());
}
